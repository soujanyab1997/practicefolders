package com.inc.skillgrama.mapper;

import com.inc.skillgrama.dto.FieldMasterDto;
import com.inc.skillgrama.entity.FieldMaster;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface FieldMasterMapper {

	FieldMasterMapper INSTANCE = Mappers.getMapper(FieldMasterMapper.class);

    // Map FieldMaster entity to FieldMasterDto
    @Mapping(source = "id", target = "fieldId")
    @Mapping(target = "link",expression = "java(\"/\"+fieldMaster.getId())")
    FieldMasterDto entityToDto(FieldMaster fieldMaster);

    // Map list of FieldMaster entities to list of FieldMasterDtos
    List<FieldMasterDto> entitiesToDtos(List<FieldMaster> fieldMasters);

    // Map FieldMasterDto back to FieldMaster entity
    @InheritInverseConfiguration  // This annotation automatically reverses the entityToDto mapping
    FieldMaster dtoToEntity(FieldMasterDto fieldMasterDto);

    // Map list of FieldMasterDtos to list of FieldMaster entities
    List<FieldMaster> dtosToEntities(List<FieldMasterDto> fieldMasterDtos);
}