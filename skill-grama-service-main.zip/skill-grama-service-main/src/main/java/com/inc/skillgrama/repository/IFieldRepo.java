package com.inc.skillgrama.repository;


import com.inc.skillgrama.entity.FieldMaster;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface IFieldRepo extends JpaRepository<FieldMaster, Long>, JpaSpecificationExecutor<FieldMaster>{

}
