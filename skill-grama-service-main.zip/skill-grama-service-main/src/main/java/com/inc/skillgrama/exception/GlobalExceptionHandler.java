package com.inc.skillgrama.exception;


import com.inc.skillgrama.dto.APIResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.List;
import java.util.stream.Collectors;


@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler({CustomException.class})
    ResponseEntity<Object> customExceptionHandler(Exception exc, ServletWebRequest request) {

        APIResponse<Object> response = new APIResponse<>().failure(exc.getMessage());
        return new ResponseEntity<>(response, new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler({NotFoundException.class})
    ResponseEntity<Object> notFoundException(Exception exc, ServletWebRequest request) {

        APIResponse<Object> response = new APIResponse<>().failure(exc.getMessage());
        return new ResponseEntity<>(response, new HttpHeaders(), HttpStatus.NOT_FOUND);
    }
    
    @ExceptionHandler({NoContentException.class})
    ResponseEntity<Object> noContentException(Exception exc, ServletWebRequest request) {

        APIResponse<Object> response = new APIResponse<>().failure(exc.getMessage());
        return new ResponseEntity<>(response, new HttpHeaders(), HttpStatus.NO_CONTENT);
    }

    @ExceptionHandler(Exception.class)
    ResponseEntity<Object> globalExceptionHandler(Exception exc, ServletWebRequest request) {

        APIResponse<Object> response = new APIResponse<>().failure(exc.getMessage());
        return new ResponseEntity<>(response, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
    
//    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
                                                                  HttpHeaders headers, HttpStatus status, WebRequest request) {

        List<FieldError> fieldErrors = ex.getBindingResult().getFieldErrors();
        List<String> errors = fieldErrors.stream().map(err -> err.getField() + " : " + err.getDefaultMessage())
                .collect(Collectors.toList());
        APIResponse<Object> response = new APIResponse<>().failure(errors.toString());
        return new ResponseEntity<>(response, headers, HttpStatus.BAD_REQUEST);
    }
}
