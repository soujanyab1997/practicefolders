package com.inc.skillgrama.controller;

import com.inc.skillgrama.dto.APIResponse;
import com.inc.skillgrama.dto.UserDto;
import com.inc.skillgrama.entity.User;
import com.inc.skillgrama.mapper.UserMapper;
import com.inc.skillgrama.service.UserService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@RequestMapping("/user")
public class UserApiRestController {

    @Autowired
    UserService userService;

    @Autowired
    UserMapper mapper;

    @PostMapping(value = "/login", produces = {MediaType.APPLICATION_JSON_VALUE})
    public APIResponse<UserDto> userLogin(@RequestBody UserDto requestBody) {
        return new APIResponse<UserDto>().success(requestBody);
    }
    
    @GetMapping("/{id}")
    @Operation(summary = "Get a user by ID", description = "Fetches a user by their ID.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved user"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    public UserDto getUser(@PathVariable Long id) {
        return userService.getUserById(id);
    }
    
    @GetMapping
    @Operation(summary = "Get all users", description = "Fetches a list of all users.")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }
    
    @PutMapping("/updateProfile/{id}")
    @Operation(summary = "Update user profile", description = "Updates the user's profile details.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully updated user"),
        @ApiResponse(responseCode = "404", description = "User not found")
    })
    public ResponseEntity<?> updateUserProfile(@PathVariable Long id, @RequestBody UserDto userDTO) {
        User updatedUser = userService.updateUserProfile(id, userDTO);
        if (updatedUser == null) {
            return ResponseEntity.status(404).body("User not found");
        }
        return ResponseEntity.ok(updatedUser);
    }
}
