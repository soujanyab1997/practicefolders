package com.inc.skillgrama.service;

import com.inc.skillgrama.dto.SkillMasterDto;
import com.inc.skillgrama.mapper.FieldMasterMapper;
import com.inc.skillgrama.mapper.SkillMasterMapper;
import com.inc.skillgrama.entity.SkillMaster;
import com.inc.skillgrama.repository.ISkillRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SkillMasterService {

    @Autowired
    private ISkillRepo skillMasterRepository;

    private final SkillMasterMapper skillMasterMapper;
    private final FieldMasterMapper fieldMasterMapper;
    
    @Autowired
    public SkillMasterService(SkillMasterMapper skillMasterMapper, FieldMasterMapper fieldMasterMapper) {
        this.skillMasterMapper = skillMasterMapper;
        this.fieldMasterMapper = fieldMasterMapper;
    }

    // Get all skills
    public List<SkillMasterDto> getAllSkills() {
        List<SkillMaster> skills = skillMasterRepository.findAll();
        return skillMasterMapper.entitiesToDtos(skills, fieldMasterMapper);
    }

    // Get skill by ID
    public SkillMasterDto getSkillById(Long id) {
        Optional<SkillMaster> skill = skillMasterRepository.findById(id);
        return skill.map(skillMaster -> skillMasterMapper.entityToDto(skillMaster, fieldMasterMapper)).orElse(null);
    }

    // Get skills by name
    public List<SkillMasterDto> getSkillsByName(String name) {
        List<SkillMaster> skills = skillMasterRepository.findByNameContaining(name);
        return skillMasterMapper.entitiesToDtos(skills, fieldMasterMapper);
    }

    // Get skills by description
    public List<SkillMasterDto> getSkillsByDescription(String description) {
        List<SkillMaster> skills = skillMasterRepository.findByDescriptionContaining(description);
        return skillMasterMapper.entitiesToDtos(skills, fieldMasterMapper);
    }

    // Get skills by FieldMaster ID (category)
    public List<SkillMasterDto> getSkillsByFieldMasterId(Long fieldId) {
        List<SkillMaster> skills = skillMasterRepository.findByFieldMasterId(fieldId);
        return skillMasterMapper.entitiesToDtos(skills, fieldMasterMapper);
    }

    // Create a new skill
    public SkillMasterDto createSkill(SkillMasterDto skillMasterDto) {
        SkillMaster skillMaster = skillMasterMapper.dtoToEntity(skillMasterDto);
        skillMaster = skillMasterRepository.save(skillMaster);
        return skillMasterMapper.entityToDto(skillMaster, fieldMasterMapper);
    }

    // Update an existing skill
    public SkillMasterDto updateSkill(Long id, SkillMasterDto skillMasterDto) {
        Optional<SkillMaster> existingSkill = skillMasterRepository.findById(id);
        if (existingSkill.isPresent()) {
            SkillMaster skillMaster = existingSkill.get();
            skillMaster = skillMasterMapper.dtoToEntity(skillMasterDto);
            //skillMaster.setId(id);  // Ensure the ID is set during update
            skillMaster = skillMasterRepository.save(skillMaster);
            return skillMasterMapper.entityToDto(skillMaster, fieldMasterMapper);
        }
        return null;
    }

    // Delete a skill by ID
    public boolean deleteSkill(Long id) {
        if (skillMasterRepository.existsById(id)) {
            skillMasterRepository.deleteById(id);
            return true;
        }
        return false;
    }
}