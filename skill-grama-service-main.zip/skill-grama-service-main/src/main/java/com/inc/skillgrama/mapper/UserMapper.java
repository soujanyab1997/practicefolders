package com.inc.skillgrama.mapper;

import com.inc.skillgrama.dto.UserDto;
import com.inc.skillgrama.entity.User;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface UserMapper {

    UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);

    // Map User entity to UserDto
    @Mapping(source = "id", target = "userId")  // This will map 'id' to 'userId' field in DTO
    UserDto entityToDto(User user);

    // Map list of User entities to list of UserDtos
    List<UserDto> entitiesToDtos(List<User> users);

    // Map UserDto back to User entity
    @InheritInverseConfiguration  // This annotation automatically reverses the entityToDto mapping
    User dtoToEntity(UserDto userDTO);

    // Map list of UserDtos to list of User entities
    List<User> dtosToEntities(List<UserDto> userDTOS);
}