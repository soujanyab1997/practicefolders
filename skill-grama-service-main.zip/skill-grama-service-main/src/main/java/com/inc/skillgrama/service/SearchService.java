//package com.inc.skillgrama.service;
//
//import com.inc.skillgrama.entity.SkillMaster;
//import com.inc.skillgrama.entity.FieldMaster;
//import com.inc.skillgrama.entity.User;
//import com.inc.skillgrama.controller.ElasticsearchController;
//import com.inc.skillgrama.dto.SearchResults;
//import com.inc.skillgrama.elasticsearch.repository.IFieldElasticsearchRepo;
//import com.inc.skillgrama.elasticsearch.repository.ISkillElasticsearchRepo;
//import com.inc.skillgrama.elasticsearch.repository.IUserElasticsearchRepo;
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class SearchService {
//	
//	private static Logger logger = LoggerFactory.getLogger(SearchService.class.getName());
//
//    @Autowired
//    private ISkillElasticsearchRepo skillElasticsearchRepo;
//
//    @Autowired
//    private IFieldElasticsearchRepo fieldElasticsearchRepo;
//
//    @Autowired
//    private IUserElasticsearchRepo userElasticsearchRepo;
//
//    public SearchResults search(String query) {
//    	logger.info("inside search method of SearchService with query - "+query);
//        List<SkillMaster> skills = skillElasticsearchRepo.findByNameContainingOrDescriptionContaining(query, query);
//        logger.info("inside search method of SearchService with skills - "+skills);
//        List<FieldMaster> fields = fieldElasticsearchRepo.findByNameContainingOrDescriptionContaining(query, query);
//        logger.info("inside search method of SearchService with fields - "+fields);
//        List<User> users = userElasticsearchRepo.findByIsMentorTrueAndFirstNameContainingOrLastNameContainingOrEmailContainingOrBioContaining(query, query, query, query);
//        logger.info("inside search method of SearchService with users - "+users);
//
//        return new SearchResults(skills, fields, users);
//    }
//}

package com.inc.skillgrama.service;

import com.inc.skillgrama.dto.FieldMasterDto;
import com.inc.skillgrama.dto.SearchResults;
import com.inc.skillgrama.dto.SkillMasterDto;
import com.inc.skillgrama.dto.UserDto;
import com.inc.skillgrama.entity.FieldMaster;
import com.inc.skillgrama.entity.FieldMaster_;
import com.inc.skillgrama.entity.SkillMaster;
import com.inc.skillgrama.entity.SkillMaster_;
import com.inc.skillgrama.entity.User;
import com.inc.skillgrama.entity.UserSkill;
import com.inc.skillgrama.entity.UserSkill_;
import com.inc.skillgrama.entity.User_;
import com.inc.skillgrama.mapper.FieldMasterMapper;
import com.inc.skillgrama.mapper.SkillMasterMapper;
import com.inc.skillgrama.mapper.UserMapper;

import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import jakarta.transaction.Transactional;

import org.hibernate.search.mapper.orm.session.SearchSession;
import org.hibernate.search.mapper.orm.Search;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class SearchService {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	private SearchSession searchSession;
	
	private final SkillMasterMapper skillMapper;
	private final FieldMasterMapper fieldMapper;
	
	@Autowired
    public SearchService(SkillMasterMapper skillMapper, FieldMasterMapper fieldMapper) {
        this.skillMapper = skillMapper;
        this.fieldMapper = fieldMapper;
    }
	
	private final UserMapper userMapper = UserMapper.INSTANCE;
	
	// Initialize the SearchSession after the EntityManager is injected
    @PostConstruct
    public void init() {
        this.searchSession = Search.session(entityManager);
    }
	
	public List<SkillMasterDto> searchSkills(String query){
		
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
	    CriteriaQuery<SkillMaster> cq = cb.createQuery(SkillMaster.class);
	    Root<SkillMaster> skillRoot = cq.from(SkillMaster.class);

	    Predicate orPredicate = cb.or(
	    		cb.like(cb.lower(skillRoot.get(SkillMaster_.NAME)), "%" + query.toLowerCase() + "%"),
	    		cb.like(cb.lower(skillRoot.get(SkillMaster_.DESCRIPTION)), "%" + query.toLowerCase() + "%")
	        );

	    Predicate isActivePredicate = cb.equal(skillRoot.get(SkillMaster_.IS_ACTIVE), true);

	    cq.select(skillRoot).where(cb.and(orPredicate, isActivePredicate));


	    List<SkillMaster> skills = entityManager.createQuery(cq).getResultList();
		
		return skillMapper.entitiesToDtos(skills, fieldMapper);
	}
	
	public List<UserDto> searchUsers(String query) {
		
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
	    CriteriaQuery<User> cq = cb.createQuery(User.class);
	    Root<User> userRoot = cq.from(User.class);
	    Join<User, UserSkill> userSkillsJoin = userRoot.join(User_.USER_SKILLS);
	    
	    cq.select(userRoot)
	    .where(cb.or(
	            cb.like(userRoot.get(User_.FIRST_NAME), "%" + query.toLowerCase() + "%"),
	            cb.like(userRoot.get(User_.LAST_NAME), "%" + query.toLowerCase() + "%"),
	            cb.like(userRoot.get(User_.EMAIL), "%" + query.toLowerCase() + "%")),
	            cb.equal(userSkillsJoin.get(UserSkill_.ROLE_ID), 1),
	            cb.equal(userRoot.get(UserSkill_.IS_ACTIVE), true));
	    
	    List<User> users = entityManager.createQuery(cq).getResultList();
	    
	    return userMapper.entitiesToDtos(users);
	}
	
	// Search fields by name or description
	public List<FieldMasterDto> searchFields(String query) {
		
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
	    CriteriaQuery<FieldMaster> cq = cb.createQuery(FieldMaster.class);
	    Root<FieldMaster> fieldRoot = cq.from(FieldMaster.class);

	    Predicate orPredicate = cb.or(
	    		cb.like(cb.lower(fieldRoot.get(FieldMaster_.NAME)), "%" + query.toLowerCase() + "%"),
	    		cb.like(cb.lower(fieldRoot.get(FieldMaster_.DESCRIPTION)), "%" + query.toLowerCase() + "%")
	        );

	    Predicate isActivePredicate = cb.equal(fieldRoot.get(FieldMaster_.IS_ACTIVE), true);

	    cq.select(fieldRoot).where(cb.and(orPredicate, isActivePredicate));

	    List<FieldMaster> fields = entityManager.createQuery(cq).getResultList();
		
		return fieldMapper.entitiesToDtos(fields);
	}
	
	// Unified search method for all entities
	public List<SearchResults> unifiedSearch(String query) {
		List<SearchResults> searchResults = new ArrayList<>();
	    
	    // Search skills and add to results
	    List<SkillMasterDto> skillResults = searchSkills(query);
	    for (SkillMasterDto skill : skillResults) {
	        searchResults.add(new SearchResults(
	            skill.getId(), 
	            skill.getName(), 
	            skill.getDescription(), 
	            "skill", 
	            "/skill/" + skill.getId()
	        ));
	    }
	    
	 // Search users and add to results
	    List<UserDto> userResults = searchUsers(query);
	    for (UserDto user : userResults) {
	        searchResults.add(new SearchResults(
	            user.getUserId(), 
	            user.getFirstName() + " " + user.getLastName(), 
	            user.getBio(), 
	            "user", 
	            "/profile/" + user.getUserId()
	        ));
	    }
	    
	 // Search fields and add to results
	    List<FieldMasterDto> fieldResults = searchFields(query);
	    for (FieldMasterDto field : fieldResults) {
	        searchResults.add(new SearchResults(
	            field.getFieldId(), 
	            field.getName(), 
	            field.getDescription(), 
	            "field", 
	            "/explore/" + field.getFieldId()
	        ));
	    }
	
	    return searchResults;
	}
}