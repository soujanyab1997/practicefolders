package com.inc.skillgrama.service;

import com.inc.skillgrama.commons.Constants;
import com.inc.skillgrama.entity.Property;
import com.inc.skillgrama.exception.NotFoundException;
import com.inc.skillgrama.repository.IPropertyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PropertyService {

    @Autowired
    IPropertyRepo propertyRepo;


    public String getProperty(String key) {
        Optional<Property> value = propertyRepo.findById(key);
        if (value.isPresent()) {
            return value.get().toString();
        }
        throw new NotFoundException(Constants.ErrorMsg.PROPERTY_NOT_FOUND);
    }
}
