package com.inc.skillgrama.commons;

public final class Constants {

    public static final String NA = "NA";
    public static final String S3_ENV = "S3_ENV";

    private Constants() {
    }

    public static final class ErrorMsg {
        public static final String ID_NOT_FOUND = "Id Not Found!";

        public static final String USERS_NOT_FOUND = "Users not found!";
        public static final String PROPERTY_NOT_FOUND = "Property not found!.";

        public static final String USER_UPDATE_FAILED = "User Details updated Failed!";

        public static final String CONTENT_STATUS = "status should be [COMPLETED|PENDING]";
        public static final String TITLE = "Template title should have at least 3 characters";
        public static final String VZ_ID_AND_TYPE_NOT_FOUND = "Particular vzID and type not found!";
        public static final String USER_ONBOARD_STATUS_NIL = "No user onboard training status found!";

        public static final String CRITERIA_NOT_FOUND = "Criteria is not match with any records! Try again..";
        public static final String MEDIA_TYPE = "Media type should be [JPEG|PNG|ICO|PDF|PPT|XSLX|DOC|HTML|MP4]";
        public static final String INVALID_INPUT_FORMAT = "I/O Error [File upload must be extension of .xlsx .xls .xlsm ]";
        public static final String INVALID_USER = " User not found. Name: ";
        public static final String EMPTY_INPUT = "Input cannot be null";
        public static final String INVALID_REQ_BODY = "Invalid input";

        private ErrorMsg() {
        }
    }
}
