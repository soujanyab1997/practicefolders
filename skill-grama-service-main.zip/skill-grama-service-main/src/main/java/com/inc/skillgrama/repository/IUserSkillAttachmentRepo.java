package com.inc.skillgrama.repository;


import com.inc.skillgrama.entity.UserSkillAttachment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface IUserSkillAttachmentRepo extends JpaRepository<UserSkillAttachment, Long>, JpaSpecificationExecutor<UserSkillAttachment> {

}
