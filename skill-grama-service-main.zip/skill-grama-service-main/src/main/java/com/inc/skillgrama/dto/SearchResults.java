package com.inc.skillgrama.dto;

import com.inc.skillgrama.entity.SkillMaster;
import com.inc.skillgrama.entity.FieldMaster;
import com.inc.skillgrama.entity.User;

import java.util.List;

//public class SearchResults {
//    private List<SkillMasterDto> skills;
//    private List<FieldMasterDto> fields;
//    private List<UserDto> users;
//
//    // Constructor
//    public SearchResults(List<SkillMasterDto> skills, List<FieldMasterDto> fields, List<UserDto> users) {
//        this.skills = skills;
//        this.fields = fields;
//        this.users = users;
//    }
//
//    // Getters and Setters
//    public List<SkillMasterDto> getSkills() {
//        return skills;
//    }
//
//    public void setSkills(List<SkillMasterDto> skills) {
//        this.skills = skills;
//    }
//
//    public List<FieldMasterDto> getFields() {
//        return fields;
//    }
//
//    public void setFields(List<FieldMasterDto> fields) {
//        this.fields = fields;
//    }
//
//    public List<UserDto> getUsers() {
//        return users;
//    }
//
//    public void setUsers(List<UserDto> users) {
//        this.users = users;
//    }
//}

public class SearchResults {
    private Long id;
    private String name;
    private String description;
    private String type;
    private String route;

    // Constructor
    public SearchResults(Long id, String name, String description, String type, String route) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.type = type;
        this.route = route;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }
}