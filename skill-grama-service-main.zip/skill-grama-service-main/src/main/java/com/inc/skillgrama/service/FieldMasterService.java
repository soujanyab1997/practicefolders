package com.inc.skillgrama.service;

import com.inc.skillgrama.dto.FieldMasterDto;
import com.inc.skillgrama.entity.FieldMaster;
import com.inc.skillgrama.entity.SkillMaster;
import com.inc.skillgrama.mapper.FieldMasterMapper;
import com.inc.skillgrama.repository.IFieldRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FieldMasterService {

    @Autowired
    private IFieldRepo fieldMasterRepository;

    @Autowired
    private FieldMasterMapper fieldMasterMapper;

    // Get all field masters
    public List<FieldMasterDto> getAllFields() {
    	List<FieldMaster> getFields =  fieldMasterRepository.findAll();
    	return fieldMasterMapper.entitiesToDtos(getFields);
    }

    // Get a specific field master by ID
    public FieldMasterDto getFieldById(Long id) {
    	Optional<FieldMaster> fields = fieldMasterRepository.findById(id);
    	return fields.map(fieldMasterMapper::entityToDto).orElse(null);
    }

    // Save a new field master
    public FieldMasterDto createField(FieldMasterDto fieldMasterDto) {
    	FieldMaster fieldMaster = fieldMasterMapper.dtoToEntity(fieldMasterDto);
    	fieldMaster = fieldMasterRepository.save(fieldMaster);
    	return fieldMasterMapper.entityToDto(fieldMaster);
    }

    // Update an existing field master
    public FieldMasterDto updateField(Long id, FieldMasterDto fieldMasterDto) {
    	Optional<FieldMaster> existingSkill = fieldMasterRepository.findById(id);
        if (existingSkill.isPresent()) {
        	FieldMaster fieldMaster = existingSkill.get();
        	fieldMaster = fieldMasterMapper.dtoToEntity(fieldMasterDto);
            fieldMaster.setId(id);
            fieldMaster = fieldMasterRepository.save(fieldMaster);
            return fieldMasterMapper.entityToDto(fieldMaster);
        } else {
            return null;
        }
    }

    // Delete a field master by ID
    public boolean deleteField(Long id) {
        if (fieldMasterRepository.existsById(id)) {
            fieldMasterRepository.deleteById(id);
            return true;
        }
        return false;
    }
}