package com.inc.skillgrama.mapper;

import com.inc.skillgrama.dto.SkillMasterDto;
import com.inc.skillgrama.entity.SkillMaster;

import org.mapstruct.Context;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring", uses = FieldMasterMapper.class)  // Use FieldMasterMapper to handle FieldMaster mapping
public interface SkillMasterMapper {

   
	SkillMasterMapper INSTANCE = Mappers.getMapper(SkillMasterMapper.class);

    // Map SkillMaster entity to SkillMasterDto
    @Mapping(source = "fieldMaster", target = "fieldMaster")
    @Mapping(target = "link",expression = "java(\"skill/\"+skillMaster.getId())")  // Map FieldMaster to FieldMasterDto
    SkillMasterDto entityToDto(SkillMaster skillMaster, @Context FieldMasterMapper fieldMasterMapper);

    // Map list of SkillMaster entities to list of SkillMasterDtos
    List<SkillMasterDto> entitiesToDtos(List<SkillMaster> skillMasters, @Context FieldMasterMapper fieldMasterMapper);

    // Map SkillMasterDto to SkillMaster entity
    @Mapping(source = "fieldMaster", target = "fieldMaster")  // Map FieldMasterDto back to FieldMaster
    SkillMaster dtoToEntity(SkillMasterDto skillMasterDto);

    // Map list of SkillMasterDtos to list of SkillMaster entities
    List<SkillMaster> dtosToEntities(List<SkillMasterDto> skillMasterDtos);
}

