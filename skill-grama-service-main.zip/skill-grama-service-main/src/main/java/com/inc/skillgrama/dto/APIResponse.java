package com.inc.skillgrama.dto;

import lombok.Data;

@Data
public class APIResponse<T> {

    private T result;
    private String errorMsg;
    private String userErrorMsg;
    private boolean isSuccess;
    private int statusCode;

    public APIResponse<T> success(T object) {
        result = object;
        isSuccess = true;
        statusCode = 0;
        return this;
    }

    public APIResponse<T> failure(String errorMsg) {
        return failure(errorMsg, "");
    }

    public APIResponse<T> failure(String errorMsg, String userErrorMsg) {
        isSuccess = false;
        statusCode = -1;
        this.errorMsg = errorMsg;
        this.userErrorMsg = userErrorMsg;
        return this;
    }
}
