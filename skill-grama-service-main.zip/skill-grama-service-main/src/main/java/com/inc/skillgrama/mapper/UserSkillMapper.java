package com.inc.skillgrama.mapper;
import java.util.List;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.inc.skillgrama.dto.UserDto;
import com.inc.skillgrama.dto.UserSkillDto;
import com.inc.skillgrama.entity.User;
import com.inc.skillgrama.entity.UserSkill;

@Mapper(componentModel = "spring")
public interface UserSkillMapper {
	UserSkillMapper INSTANCE = Mappers.getMapper(UserSkillMapper.class);

    // Map User entity to UserDto
//    @Mapping(source = "id", target = "userId")  // This will map 'id' to 'userId' field in DTO
    UserSkillDto entityToDto(UserSkill userSkill);

    // Map list of User entities to list of UserDtos
    List<UserSkillDto> entitiesToDtos(List<UserSkill> userSkills);

    // Map UserDto back to User entity
    @InheritInverseConfiguration  // This annotation automatically reverses the entityToDto mapping
    UserSkill dtoToEntity(UserSkillDto userSkillDto);

    // Map list of UserDtos to list of User entities
    List<UserSkill> dtosToEntities(List<UserSkillDto> userSkillDtos);
}
