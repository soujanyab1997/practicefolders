package com.inc.skillgrama.repository;


import com.inc.skillgrama.entity.UserSkill;
import com.inc.skillgrama.entity.UserSkillTracker;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface IUserSkillTrackerRepo extends JpaRepository<UserSkillTracker, Long>, JpaSpecificationExecutor<UserSkillTracker> {

}
