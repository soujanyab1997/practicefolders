package com.inc.skillgrama.repository;

import com.inc.skillgrama.entity.RoleMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface IRoleMasterRepo extends JpaRepository<RoleMaster, Long>, JpaSpecificationExecutor<RoleMaster> {

}
