package com.inc.skillgrama.repository;


import com.inc.skillgrama.entity.Property;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.List;
import java.util.Set;

public interface IPropertyRepo extends JpaRepository<Property, String>, JpaSpecificationExecutor<String> {
    List<Property> findByKey(String key);

    List<Property> findByKeyInIgnoreCase(Set<String> keys);
}
