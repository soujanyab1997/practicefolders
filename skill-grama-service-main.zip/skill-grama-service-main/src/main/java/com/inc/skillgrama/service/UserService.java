package com.inc.skillgrama.service;

import com.inc.skillgrama.dto.UserDto;
import com.inc.skillgrama.entity.User;
import com.inc.skillgrama.mapper.UserMapper;
import com.inc.skillgrama.repository.IUserRepo;
import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class UserService {

    private static final Logger log = LoggerFactory.getLogger(UserService.class);

    @Autowired
    IUserRepo userRepo;

    @Autowired
    UserMapper userMapper;
    
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }
    
    public UserDto getUserById(Long id) {
        User user = userRepo.findById(id)
            .orElseThrow(() -> new RuntimeException("User not found"));
        
        return userMapper.entityToDto(user); // Using MapStruct to map entity to DTO
    }
    
 // Update user profile
    public User updateUserProfile(Long id, UserDto userDTO) {
        Optional<User> userOptional = userRepo.findById(id);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            // Map the updated fields from userDTO to the user entity
            user = userMapper.dtoToEntity(userDTO); // Mapping DTO to entity
            user.setId(id);  // Make sure to keep the same ID
            
            return userRepo.save(user);
        }
        return null;  // Return null if not found
    }
}
