package com.inc.skillgrama;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.inc.skillgrama")
public class SkillgramaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillgramaApplication.class, args);
	}

}
