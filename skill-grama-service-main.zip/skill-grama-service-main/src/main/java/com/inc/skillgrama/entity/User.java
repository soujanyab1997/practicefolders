package com.inc.skillgrama.entity;

import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.FullTextField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.GenericField;
import org.hibernate.search.mapper.pojo.mapping.definition.annotation.Indexed;
import org.springframework.data.annotation.Transient;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data // This annotation automatically generates getters, setters, toString, equals, and hashCode methods.
@Entity
@Indexed
@Table(name = "sg_users", uniqueConstraints = {@UniqueConstraint(columnNames = "email")})
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @FullTextField
    @Column(name = "first_name", nullable = false, length = 50)
    private String firstName;

    @FullTextField
    @Column(name = "last_name", nullable = false, length = 50)
    private String lastName;

    @FullTextField
    @Column(nullable = false, length = 250)
    private String email;

    private String bio;

    private String experience;

    private String company;

    @Column(name = "profile_pic")
    private byte[] profilePic;

    @Column(nullable = false, length = 50)
    private String password;

    @Column(name = "sso_enabled")
    private Boolean ssoEnabled = false;

    private String status;

    @GenericField
    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "created_by")
    private Long createdBy;

    @CreationTimestamp
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @Column(name = "created_date", updatable = false)
    private LocalDateTime createdDate;

    @Column(name = "last_modified_by")
    private Long lastModifiedBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @Column(name = "last_modified_date")
    private LocalDateTime lastModifiedDate;

    @Column(name = "approved_by")
    private Long approvedBy;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    @Column(name = "approved_on")
    private LocalDateTime approvedOn;
    

    @Transient
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private List<UserSkill> userSkills = new ArrayList<>();

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "user_id")
    private List<Notification> notifications = new ArrayList<>();

}