package com.inc.skillgrama.controller;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.inc.skillgrama.dto.FieldMasterDto;
import com.inc.skillgrama.dto.PostMentorRequest;
import com.inc.skillgrama.dto.UserSkillAttachmentDto;
import com.inc.skillgrama.entity.FieldMaster;
import com.inc.skillgrama.entity.UserSkillAttachment;
import com.inc.skillgrama.mapper.FieldMasterMapper;
import com.inc.skillgrama.mapper.UserSkillAttachmentMapper;
import com.inc.skillgrama.service.FieldMasterService;
import com.inc.skillgrama.service.UserSkillAttachmentService;

@RestController
@RequestMapping("/api/skillAttachments")
public class UserSkillAttachmentController {
	
	 @Autowired
	 private UserSkillAttachmentService userSkillAttachmentService;

	 @Autowired
	 private UserSkillAttachmentMapper userSkillAttachmentMapper;
	
	// Create a new field master
    @PostMapping
    public ResponseEntity<List<UserSkillAttachmentDto>> createField(@RequestBody List<PostMentorRequest> postMentorRequestList) {
    	List<UserSkillAttachmentDto> userSkillAttachmentList=new LinkedList<UserSkillAttachmentDto>();
        for(PostMentorRequest postMentorRequest:postMentorRequestList) {
    	UserSkillAttachmentDto userSkillAttachment = userSkillAttachmentService.createUserSkillAttachment(postMentorRequest);
    	userSkillAttachmentList.add(userSkillAttachment);
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(userSkillAttachmentList);
    }

}
