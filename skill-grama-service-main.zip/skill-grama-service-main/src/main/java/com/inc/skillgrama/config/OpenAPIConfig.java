package com.inc.skillgrama.config;

import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenAPIConfig {

    @Bean
    public GroupedOpenApi publicApi() {
        return GroupedOpenApi.builder()
                .group("public")
                .packagesToScan("com.inc.skillgrama.controller") // Package where your controllers are
                .pathsToMatch("/**") // Match all paths
                .build();
    }
}