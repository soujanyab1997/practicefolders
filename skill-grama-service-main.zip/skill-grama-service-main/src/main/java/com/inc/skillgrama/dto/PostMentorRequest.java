package com.inc.skillgrama.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PostMentorRequest {
	private Long userId;
    private Long skillId;
    private String mediaUrl;
    private String certificates;
    private String justification;
    private Boolean isActive;
}
