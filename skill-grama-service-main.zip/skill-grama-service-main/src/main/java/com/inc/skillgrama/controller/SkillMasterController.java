package com.inc.skillgrama.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.inc.skillgrama.dto.SkillMasterDto;
import com.inc.skillgrama.service.SkillMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/skills")
public class SkillMasterController {

    @Autowired
    private SkillMasterService skillMasterService;

    // Get all skills
    @GetMapping
    public ResponseEntity<List<SkillMasterDto>> getAllSkills() throws JsonProcessingException {
        List<SkillMasterDto> skills = skillMasterService.getAllSkills();

        return ResponseEntity.ok(skills);
    }

    // Get skill by ID
    @GetMapping("/{id}")
    public ResponseEntity<SkillMasterDto> getSkillById(@PathVariable Long id) {
        SkillMasterDto skill = skillMasterService.getSkillById(id);
        if (skill != null) {
            return ResponseEntity.ok(skill);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    // Get skill by skill name
    @GetMapping("/name/{name}")
    public ResponseEntity<List<SkillMasterDto>> getSkillsByName(@PathVariable String name) {
        List<SkillMasterDto> skills = skillMasterService.getSkillsByName(name);
        if (!skills.isEmpty()) {
            return ResponseEntity.ok(skills);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    // Get skill by description
    @GetMapping("/description/{description}")
    public ResponseEntity<List<SkillMasterDto>> getSkillsByDescription(@PathVariable String description) {
        List<SkillMasterDto> skills = skillMasterService.getSkillsByDescription(description);
        if (!skills.isEmpty()) {
            return ResponseEntity.ok(skills);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    // Get skill by FieldMaster ID (category)
    @GetMapping("/field/{fieldId}")
    public ResponseEntity<List<SkillMasterDto>> getSkillsByFieldMasterId(@PathVariable Long fieldId) {
        List<SkillMasterDto> skills = skillMasterService.getSkillsByFieldMasterId(fieldId);
        if (!skills.isEmpty()) {
            return ResponseEntity.ok(skills);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    // Search skills (flexible search by skill name, description, or FieldMaster category name)
//    @GetMapping("/search")
//    public ResponseEntity<List<SkillMasterDto>> searchSkills(@RequestParam(required = false) String query) {
//        List<SkillMasterDto> skills = skillMasterService.searchSkills(query);
//        return ResponseEntity.ok(skills);
//    }

    // Post a new skill
    @PostMapping
    public ResponseEntity<SkillMasterDto> createSkill(@RequestBody SkillMasterDto skillMasterDto) {
        SkillMasterDto createdSkill = skillMasterService.createSkill(skillMasterDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdSkill);
    }

    // Update an existing skill
    @PutMapping("/{id}")
    public ResponseEntity<SkillMasterDto> updateSkill(@PathVariable Long id, @RequestBody SkillMasterDto skillMasterDto) {
        SkillMasterDto updatedSkill = skillMasterService.updateSkill(id, skillMasterDto);
        if (updatedSkill != null) {
            return ResponseEntity.ok(updatedSkill);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    // Delete a skill by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSkill(@PathVariable Long id) {
        boolean isDeleted = skillMasterService.deleteSkill(id);
        if (isDeleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }
}