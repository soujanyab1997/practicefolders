package com.inc.skillgrama.config;

import org.hibernate.search.mapper.orm.Search;
import org.hibernate.search.mapper.orm.session.SearchSession;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;

import jakarta.annotation.PostConstruct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Component
@Transactional
public class HibernateSearchConfig {
	
	@PersistenceContext
	private EntityManager entityManager;
	
	private SearchSession searchSession;
	
	@PostConstruct
    public void init() {
        this.searchSession = Search.session(entityManager);
    }
	
	@EventListener(ApplicationReadyEvent.class)
    public void initializeHibernateSearch() {
		System.out.println("Initializing Hibernate Search...");
        startIndexing();
    }
	
	public void startIndexing() {
		try {
			searchSession.massIndexer().startAndWait();
			System.out.println("Hibernate search indexing completed!");
		} catch (InterruptedException e) {
			throw new RuntimeException("Failed to initialize Hibernate search indexing "+e);
		}
	}

}