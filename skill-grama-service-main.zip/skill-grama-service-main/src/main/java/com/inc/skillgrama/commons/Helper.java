package com.inc.skillgrama.commons;

import jakarta.servlet.http.HttpServletRequest;

public class Helper {
    private Helper() {

    }

    public static String httpRequestCatcher(HttpServletRequest httpRequest, String header) {
        return httpRequest.getHeader(header);
    }

}
