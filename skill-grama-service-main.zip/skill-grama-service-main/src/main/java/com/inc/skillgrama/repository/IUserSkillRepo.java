package com.inc.skillgrama.repository;


import com.inc.skillgrama.entity.UserSkill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface IUserSkillRepo extends JpaRepository<UserSkill, Long>, JpaSpecificationExecutor<UserSkill> {

}
