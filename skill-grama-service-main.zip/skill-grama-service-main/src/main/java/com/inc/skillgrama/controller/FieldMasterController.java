package com.inc.skillgrama.controller;

import com.inc.skillgrama.dto.FieldMasterDto;
import com.inc.skillgrama.entity.FieldMaster;
import com.inc.skillgrama.mapper.FieldMasterMapper;
import com.inc.skillgrama.service.FieldMasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/fields")
public class FieldMasterController {

    @Autowired
    private FieldMasterService fieldMasterService;

    @Autowired
    private FieldMasterMapper fieldMasterMapper;

    // Get all field masters
    @GetMapping
    public ResponseEntity<List<FieldMasterDto>> getAllFields() {
    	List<FieldMasterDto> allFields = fieldMasterService.getAllFields();
    	return ResponseEntity.ok(allFields);
    }

    // Get a field master by ID
    @GetMapping("/{id}")
    public ResponseEntity<FieldMasterDto> getFieldById(@PathVariable Long id) {
        FieldMasterDto fieldMaster = fieldMasterService.getFieldById(id);
        if (fieldMaster != null) {
            return ResponseEntity.ok(fieldMaster);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    // Create a new field master
    @PostMapping
    public ResponseEntity<FieldMasterDto> createField(@RequestBody FieldMasterDto fieldMasterDto) {
        FieldMasterDto savedField = fieldMasterService.createField(fieldMasterDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedField);
    }

    // Update an existing field master
    @PutMapping("/{id}")
    public ResponseEntity<FieldMasterDto> updateField(@PathVariable Long id, @RequestBody FieldMasterDto fieldMasterDto) {
        FieldMasterDto updatedField = fieldMasterService.updateField(id, fieldMasterDto);
        if (updatedField != null) {
            return ResponseEntity.ok(updatedField);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }

    // Delete a field master
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteField(@PathVariable Long id) {
        boolean isDeleted = fieldMasterService.deleteField(id);
        if (isDeleted) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
    }
}