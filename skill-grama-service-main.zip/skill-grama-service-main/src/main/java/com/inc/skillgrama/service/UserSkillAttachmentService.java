package com.inc.skillgrama.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.inc.skillgrama.dto.PostMentorRequest;
import com.inc.skillgrama.dto.UserSkillAttachmentDto;
import com.inc.skillgrama.dto.UserSkillDto;
import com.inc.skillgrama.entity.UserSkill;
import com.inc.skillgrama.entity.UserSkillAttachment;
import com.inc.skillgrama.mapper.UserSkillAttachmentMapper;
import com.inc.skillgrama.mapper.UserSkillMapper;
import com.inc.skillgrama.repository.IUserSkillAttachmentRepo;
import com.inc.skillgrama.repository.IUserSkillRepo;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserSkillAttachmentService {

	 @Autowired
	 IUserSkillAttachmentRepo userSkillAttachmentRepo;

	 @Autowired
	 UserSkillAttachmentMapper userSkillAttachmentMapper;
	 
	 @Autowired
	 UserSkillMapper userSkillMapper;
	 
	 @Autowired
	 IUserSkillRepo userSkillRepo;
	 
	 // Create a new User Skill Attachment
	    public UserSkillAttachmentDto createUserSkillAttachment(PostMentorRequest postMentorRequest) {
	    	UserSkillDto userSkillDto=new UserSkillDto(postMentorRequest.getUserId(),Long.parseLong("1"), postMentorRequest.getSkillId(), "active");
	    	UserSkill userSkill =userSkillMapper.dtoToEntity(userSkillDto);
	    	UserSkill newUserSkill= userSkillRepo.save(userSkill);
	    	UserSkillAttachmentDto userSkillAttachmentDto=new UserSkillAttachmentDto(newUserSkill.getId(), postMentorRequest.getMediaUrl(), postMentorRequest.getCertificates(), postMentorRequest.getJustification(), postMentorRequest.getIsActive());
	        UserSkillAttachment userSkillAttachment = userSkillAttachmentMapper.dtoToEntity(userSkillAttachmentDto);
	        userSkillAttachment = userSkillAttachmentRepo.save(userSkillAttachment);
	        return userSkillAttachmentMapper.entityToDto(userSkillAttachment);
	    }
}
