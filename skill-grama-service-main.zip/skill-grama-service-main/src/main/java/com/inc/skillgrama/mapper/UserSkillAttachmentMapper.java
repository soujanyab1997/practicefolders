package com.inc.skillgrama.mapper;

import java.util.List;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import com.inc.skillgrama.dto.UserSkillAttachmentDto;
import com.inc.skillgrama.entity.UserSkillAttachment;

@Mapper(componentModel = "spring")
public interface UserSkillAttachmentMapper {
	UserSkillAttachmentMapper INSTANCE = Mappers.getMapper(UserSkillAttachmentMapper.class);

    // Map FieldMaster entity to FieldMasterDto
//    @Mapping(source = "id", target = "fieldId")
//    @Mapping(source = "isActive", target = "active")
    UserSkillAttachmentDto entityToDto(UserSkillAttachment userSkillAttachment);

    // Map list of FieldMaster entities to list of FieldMasterDtos
    List<UserSkillAttachmentDto> entitiesToDtos(List<UserSkillAttachment> userSkillAttachments);

    // Map FieldMasterDto back to FieldMaster entity
    @InheritInverseConfiguration  // This annotation automatically reverses the entityToDto mapping
    UserSkillAttachment dtoToEntity(UserSkillAttachmentDto userSkillAttachmentDto);

    // Map list of FieldMasterDtos to list of FieldMaster entities
    List<UserSkillAttachment> dtosToEntities(List<UserSkillAttachmentDto> userSkillAttachmentDto);

}
