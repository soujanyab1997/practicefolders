package com.inc.skillgrama.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonFormat;

@Getter
@Setter
public class SkillMasterDto {

	private Long id;
    private String name;
    private String description;
//    private ArrayList<String> expectations;
//    private ArrayList<String> references;
    private Boolean isActive;
    private Long createdBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime createdDate;
    private Long lastModifiedBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime lastModifiedDate;
    private Long approvedBy;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss")
    private LocalDateTime approvedOn;
    private String justificationRemark;
    private String status;
    private String link;
    private FieldMasterDto fieldMaster;
}