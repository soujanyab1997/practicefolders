package com.inc.skillgrama;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillgramaApplicationTests {

	@Test
	void contextLoads() {
	}

}
