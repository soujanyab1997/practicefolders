-- properties

-- Drop table

-- DROP TABLE properties;

CREATE TABLE properties (
	id serial2 NOT NULL,
	"key" varchar(100) NOT NULL,
	value text NULL,
	last_modified_time timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	last_modified_by int4 NULL,
	display_name varchar NULL,
	CONSTRAINT properties_pk PRIMARY KEY (id, key),
	CONSTRAINT properties_un UNIQUE (key)
);
CREATE INDEX properties_idx ON properties USING btree (key);
-- sg_mas_fields definition

-- Drop table

-- DROP TABLE sg_mas_fields;

CREATE TABLE sg_mas_fields (
	id serial4 NOT NULL,
	"name" varchar(250) NOT NULL,
	description text NULL,
	is_active bool NULL DEFAULT true,
	created_by int4 NULL,
	created_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	last_modified_by int4 NULL,
	last_modified_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	approved_by int4 NULL,
	approved_on timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	justification_remark text NULL,
	status varchar(25) NULL,
	CONSTRAINT sg_field_name UNIQUE (name),
	CONSTRAINT sg_field_pk PRIMARY KEY (id)
);


-- sg_mas_roles definition

-- Drop table

-- DROP TABLE sg_mas_roles;

CREATE TABLE sg_mas_roles (
	id serial4 NOT NULL,
	"name" varchar(25) NOT NULL,
	is_active bool NULL DEFAULT true,
	created_by int4 NULL,
	created_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	approved_by int4 NULL,
	approved_on timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT sg_mas_role_name UNIQUE (name),
	CONSTRAINT sg_mas_role_pk PRIMARY KEY (id)
);


-- sg_notifications definition

-- Drop table

-- DROP TABLE sg_notifications;

CREATE TABLE sg_notifications (
	id serial4 NOT NULL,
	user_id int4 NULL,
	message varchar NULL,
	components varchar NULL,
	is_read bool NULL,
	created_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT sg_notifications_pk PRIMARY KEY (id)
);


-- sg_user_audit_trails definition

-- Drop table

-- DROP TABLE sg_user_audit_trails;

CREATE TABLE sg_user_audit_trails (
	id serial4 NOT NULL,
	component varchar NULL,
	"comments" varchar NULL,
	last_modified_by int4 NULL,
	last_modified_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT sg_user_audit_trails_pk PRIMARY KEY (id)
);


-- sg_user_skill_tracking definition

-- Drop table

-- DROP TABLE sg_user_skill_tracking;

CREATE TABLE sg_user_skill_tracking (
	id serial4 NOT NULL,
	learner_id int4 NOT NULL,
	mentor_id int4 NOT NULL,
	skill_id int4 NOT NULL,
	status varchar(25) NULL,
	duration varchar NULL,
	review varchar NULL,
	rating int4 NULL,
	notes text NULL,
	resources text NULL,
	session_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	created_by int4 NULL,
	created_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	last_modified_by int4 NULL,
	last_modified_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT sg_skill_tracking_pk PRIMARY KEY (id)
);


-- sg_user_skills_attachments definition

-- Drop table

-- DROP TABLE sg_user_skills_attachments;

CREATE TABLE sg_user_skills_attachments (
	id serial4 NOT NULL,
	uskl_id int4 NULL,
	is_active bool NULL DEFAULT true,
	media_url varchar NULL,
	certificates varchar NULL,
	justification varchar NULL,
	created_by int4 NULL,
	created_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	last_modified_by int4 NULL,
	last_modified_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	approved_by int4 NULL,
	approved_on timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT sg_user_skills_attachments_pk PRIMARY KEY (id)
);


-- sg_users definition

-- Drop table

-- DROP TABLE sg_users;

CREATE TABLE sg_users (
	id serial4 NOT NULL,
	first_name varchar(50) NOT NULL,
	last_name varchar(50) NULL,
	email varchar(250) NOT NULL,
	bio text NULL,
	experience varchar NULL,
	company varchar NULL,
	profile_pic bytea NULL,
	is_active bool NULL DEFAULT true,
	"password" varchar(50) NOT NULL,
	sso_enabled bool NOT NULL DEFAULT false,
	status varchar(25) NULL,
	created_by int4 NULL,
	created_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	approved_by int4 NULL,
	approved_on timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	last_modified_by int4 NULL,
	last_modified_date timestamp NULL,
	CONSTRAINT sg_users_name UNIQUE (email),
	CONSTRAINT sg_users_pk PRIMARY KEY (id)
);


-- sg_mas_skills definition

-- Drop table

-- DROP TABLE sg_mas_skills;

CREATE TABLE sg_mas_skills (
	id serial4 NOT NULL,
	"name" varchar(250) NOT NULL,
	description text NULL,
	field_id int4 NULL,
	is_active bool NULL DEFAULT true,
	created_by int4 NULL,
	created_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	last_modified_by int4 NULL,
	last_modified_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	approved_by int4 NULL,
	approved_on timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	justification_remark text NULL,
	status varchar(25) NULL,
	CONSTRAINT sg_skill_name UNIQUE (name),
	CONSTRAINT sg_skills_pk PRIMARY KEY (id),
	CONSTRAINT sg_skills_fk FOREIGN KEY (field_id) REFERENCES sg_mas_fields(id)
);


-- sg_user_skills definition

-- Drop table

-- DROP TABLE sg_user_skills;

CREATE TABLE sg_user_skills (
	id serial4 NOT NULL,
	user_id int4 NOT NULL,
	role_id int4 NOT NULL,
	skill_id int4 NOT NULL,
	is_active bool NULL DEFAULT true,
	status varchar(25) NULL,
	created_by int4 NULL,
	created_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	last_modified_by int4 NULL,
	last_modified_on timestamp NULL DEFAULT CURRENT_TIMESTAMP,
	CONSTRAINT sg_user_skills_pk PRIMARY KEY (id),
	CONSTRAINT sg_user_skills_un UNIQUE (user_id, role_id, skill_id),
	CONSTRAINT sg_user_skills_fk FOREIGN KEY (role_id) REFERENCES sg_mas_roles(id),
	CONSTRAINT sg_user_skills_fk_1 FOREIGN KEY (user_id) REFERENCES sg_users(id),
	CONSTRAINT sg_user_skills_fk_2 FOREIGN KEY (skill_id) REFERENCES sg_mas_skills(id)
);
