import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import federation from "@originjs/vite-plugin-federation";

// https://vite.dev/config/
export default defineConfig({
  plugins: [react(),
    federation({
      name: "skillGrama",
      filename: "remoteEntry.js",
      exposes: {
        "./SkillGrama": "./src/SkillGrama.jsx",
      },
      shared: ["react","react-dom","react-redux"],
    })
  ],
  resolve: {
    alias: {
      process: 'process/browser', // Alias for process
    },
  },
  define: {
    'process.env': {}, // Define process.env as an empty object if it's required
  },
  optimizeDeps: {
    include: ['process'], // Ensure `process` is included in optimized dependencies
  },
  build: {
    target: 'ES2022'
  },
});