import express from "express";
import * as path from "path";
import cors from "cors";
import { fileURLToPath } from "url";
const app = express();

const environment = process.env.VITE_ENVIRONMENT || "SIT";
const port = process.env.VITE_PORT || 3004;
const context_root = process.env.VITE_CONTEXT_ROOT || "edap-ui";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());

app.use(express.static("dist"));

app.get("/" + context_root + "/health", (req, res) => {
  res.status(200).send("Ok");
});

app.get("/" + context_root + "/info", (req, res) => {
  res.status(200).send("Ok");
});

app.get("/skill-grama/*", function (req, res) {
  res.sendFile(path.join(__dirname, "dist/index.html"), function (err) {
    if (err) {
      res.status(500).send(err);
    }
  });
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
