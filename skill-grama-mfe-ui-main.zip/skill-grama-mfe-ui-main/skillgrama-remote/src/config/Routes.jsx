import React, { Suspense } from "react";
import { Route, Routes } from "react-router-dom";
import Loading from "../screens/Loader";
import SkillPage from "../screens/skills/SkillPage";
import { useLocation } from "react-router-dom";
import { RegisterMentor } from "../screens/registerMentor/RegisterMentor";
import ProfilePage from "../screens/profile/ProfilePage";
import Landing from "../screens/Landing";
import CardHoverEffectDemo from "../screens/explore/Explore";
import ITSkillList from "../screens/skills/SkillList";



const ScreenRouter = () => {

  const path=useLocation();
  const id=path.pathname;
  console.log(id); 
 
  return (
    <Routes>
      <Route
        path="/"
        element={
          <Suspense fallback={<Loading />}>
            <Landing />
          </Suspense>
        }
      />

      <Route
        path="/explore"
        element={
          <Suspense fallback={<Loading />}>
            <CardHoverEffectDemo />
          </Suspense>
        }
      />
      
       <Route
        path="/explore/:id"
        element={
          <Suspense fallback={<Loading />}>
            <ITSkillList/>
          </Suspense>
        }
      />
      <Route path='explore/:id/skill/:id' element={<SkillPage/>}/>
      <Route path='skill/:id' element={<SkillPage/>}/>

      <Route
        path="/register"
        element={
          <Suspense fallback={<Loading />}>
            <RegisterMentor />
          </Suspense>
        }
      />

      <Route
        path="/profile"
        element={
          <Suspense fallback={<Loading />}>
            <ProfilePage />
          </Suspense>
        }
      />
    </Routes>
  );
};

export default ScreenRouter;
