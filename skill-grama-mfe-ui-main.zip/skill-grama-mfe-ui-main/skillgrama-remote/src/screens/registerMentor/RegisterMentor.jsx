"use client";
import React, { useEffect, useState } from "react";
import { Label } from "./Label";
import { Input } from "./Input";
import { cn } from "../../utils/cn";
import { useSelector } from "react-redux";
import { getallFields } from "../../Service/FieldService";
import { getSkillsbyCategory } from "../../Service/SkillService";

export function RegisterMentor() {
  const { isCreateMentor } = useSelector((state) => state.users);
  const [skills, setSkills] = useState([
    {
      skillId: "",
      skillName: "",
      skillExperience: "",
      skillURL: "",
      file: null,
    },
  ]);
  const [addedskills, setAddedskills] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(""); // Track selected category
  const [availableSkills, setAvailableSkills] = useState([]); // Skills based on selected category
  const [categoryName,setCategoryName]=useState("")
  const fetchCategories = async () => {
    try {
      setCategories(await getallFields());
    } catch (error) {
      console.log("Error", error);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, [categories]);

  useEffect(() => {
    if (selectedCategory) {
      fetchSkills();
    }
  }, [selectedCategory]); // Re-fetch skills whenever the selected category changes
  const fetchSkills = async () => {
    try {
      const response = await getSkillsbyCategory(selectedCategory)
      setAvailableSkills(response); 
    } catch (error) {
      console.error("Error fetching skills:", error);
    }
  };
  const handleCategoryChange = (e) => {
    // console.log("categoryName ",categoryName)
    console.log(e.target.value)
    const fieldId = e.target.value.split(',')[0];
    const categoryname = e.target.value.split(',')[1];
    setSelectedCategory(fieldId); // Update selected category
    setCategoryName(categoryname)
    // setSkills((prevSkills) => 
    //   prevSkills.map((skill, index) => ({
    //     ...skill, 
    //     category: categories.find(category => category.fieldId === fieldId)?.name || "" 
    //   }))
    // );
  };
  const handleSkillChange = (index, event) => {
    // const updatedSkills = [...skills];
    // updatedSkills[index][event.target.name] = event.target.value;
    // setSkills(updatedSkills);

    const selectedSkill = availableSkills.find(skill => skill.name === event.target.value);
    if (selectedSkill) {
      console.log("selected skill ",selectedSkill)
      const updatedSkills = [...skills];
      updatedSkills[index] = {
        ...updatedSkills[index],
        skillId: selectedSkill.id,  
        skillName: selectedSkill.name,  
      };
      console.log("updated skills ",updatedSkills)
      setSkills(updatedSkills);
    }
    else{
    const updatedSkills = [...skills];
    updatedSkills[index][event.target.name] = event.target.value;
    setSkills(updatedSkills);
    }
  };
  const handleSkillFileChange = (index, event) => {
    const values = [...skills];
    values[index].file = event.target.files[0];
    setSkills(values);
  };
  const addSkill = () => {
    const newSkill = {
      skillId: "",
      skillName: "",
      skillExperience: "",
      skillURL: "",
      file: null,
    };
    console.log("skills",skills)
    setAddedskills((prevAddedSkills) => {
      const updatedSkills = [...prevAddedSkills, ...skills];
      return updatedSkills;
    });
    setSkills([newSkill]);
  };
  useEffect (()=>{
    console.log("added skills ",addedskills)
  },[addedskills])

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted");
  };
  return (
    <div
      className="max-w-md w-full mx-auto rounded-none md:rounded-2xl p-4 md:p-8 shadow-input bg-white dark:bg-black "
      style={{ border: "1px solid #afadad" }}
    >
      <h2 className="font-bold text-xl text-orange text-neutral-800 dark:text-neutral-200">
        Welcome to SkillGrama
      </h2>
      <form className="my-8" onSubmit={handleSubmit}>
        <div className="mb-4">
          <h3 className="text-lg font-semibold text-neutral-800 dark:text-neutral-200">
            Skills
          </h3>
          <p className="text-sm text-neutral-600 dark:text-neutral-300 mb-4">
            Add your skill and years of experience. You can add multiple skills
            by clicking on 'Add Another Skill' below.
          </p>
          <div className="space-y-4">
            <div className="space-y-2">
              <div className="flex flex-col mb-4">
                <Label htmlFor="category">Category</Label>
                <select
                  id="category"
                  name="category"
                  className="border p-2 rounded-md mt-2" // Added mt-2 for spacing
                  onChange={(e) => handleCategoryChange(e)}
                >
                  <option value="">Select a category</option>
                  {categories.map((category, index) => (
                    <option key={index} value={category.fieldId + "," + category.name}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col mb-4">
                <Label htmlFor="skillname">Skill Name</Label>
                <select
                  id="skillname"
                  name="skillName"
                  className="border p-2 rounded-md mt-2" // Added mt-2 for spacing
                  onChange={(e) => handleSkillChange(0, e)}
                >
                  <option value="">Select a skill</option>
                  {availableSkills.map((skill) => (
                    <option key={skill.id} value={skill.name}>
                      {skill.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex flex-col mb-4">
                <Label htmlFor="skillexperience">Experience (in years)</Label>
                <Input
                  id="skillexperience"
                  name="skillExperience"
                  value={skills[0].skillExperience}
                  placeholder="e.g., 3"
                  type="number"
                  onChange={(e) => handleSkillChange(0, e)}
                />
              </div>
              <p className="text-sm text-neutral-600 dark:text-neutral-300 mb-4">
                Upload proof of your certifications either by giving a URL or by
                uploading a file.
              </p>
              <div className="flex flex-col mb-4">
                <Label htmlFor="skillurl">Skill URL</Label>
                <Input
                  id="skillurl"
                  name="skillURL"
                  value={skills[0].skillURL}
                  placeholder="e.g., https://github.com/..."
                  type="url"
                  onChange={(e) => handleSkillChange(0, e)}
                />
              </div>
              <div className="flex flex-col mb-4">
                <Label htmlFor="fileupload">Upload File</Label>
                <Input
                  id="fileupload"
                  name="file"
                  type="file"
                  onChange={(e) => handleSkillFileChange(0, e)}
                />
              </div>
            </div>
            <button
              type="button"
              onClick={addSkill}
              className="text-blue-500 mt-2 hover:underline"
            >
              Add Another Skill
            </button>
          </div>
        </div>
        <div className="mb-4">
          <h4 className="text-lg font-semibold text-neutral-800 dark:text-neutral-200">
            Added Skills
          </h4>
          <p className="text-sm text-neutral-600 dark:text-neutral-300 mb-4">
            Your added skills will appear below.
          </p>
          {addedskills.length > 0 ? (
            <ul className="list-disc pl-5">
              {addedskills.map((skill, index) => (
                <li
                  key={index}
                  className="text-neutral-700 dark:text-neutral-300"
                >
                  {/* <strong>{categoryName+"-"}</strong>  */}
                  <strong>{skill.skillName}</strong> (Experience:{" "}
                  {skill.skillExperience} years)
                  {skill.skillURL && (
                    <span className="ml-2 text-blue-600">
                      <a
                        href={skill.skillURL}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {skill.skillURL}
                      </a>
                    </span>
                  )}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-neutral-600 dark:text-neutral-300">
              No skills added yet.
            </p>
          )}
        </div>
        <button
          className="bg-gradient-to-br relative group/btn from-black dark:from-zinc-900 dark:to-zinc-900 to-neutral-600 block dark:bg-zinc-800 w-full text-white rounded-md h-10 font-medium shadow-[0px_1px_0px_0px_#ffffff40_inset,0px_-1px_0px_0px_#ffffff40_inset] dark:shadow-[0px_1px_0px_0px_var(--zinc-800)_inset,0px_-1px_0px_0px_var(--zinc-800)_inset]"
          type="submit"
        >
          Register &rarr;
          <BottomGradient />
        </button>
        <div className="bg-gradient-to-r from-transparent via-neutral-300 dark:via-neutral-700 to-transparent my-8 h-[1px] w-full" />
      </form>
    </div>
  );
}
const BottomGradient = () => {
  return (
    <>
      <span className="group-hover/btn:opacity-100 block transition duration-500 opacity-0 absolute h-px w-full -bottom-px inset-x-0 bg-gradient-to-r from-transparent via-cyan-500 to-transparent" />
      <span className="group-hover/btn:opacity-100 blur-sm block transition duration-500 opacity-0 absolute h-px w-1/2 mx-auto -bottom-px inset-x-10 bg-gradient-to-r from-transparent via-indigo-500 to-transparent" />
    </>
  );
};
const LabelInputContainer = ({ children, className }) => {
  return (
    <div className={cn("flex flex-col space-y-2 w-full", className)}>
      {children}
    </div>
  );
};