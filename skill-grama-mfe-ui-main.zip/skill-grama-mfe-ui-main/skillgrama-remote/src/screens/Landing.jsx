import { useNavigate } from "react-router-dom";
import { AnimatedTooltip } from "../components/ui/AnimatedTooltip";
import { useDispatch } from "react-redux";
import { setIsCreateMentor } from "../Redux/UserSlice";

const people = [
  {
    id: 1,
    name: "John Doe",
    designation: "Software Engineer",
    image:
      "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=3387&q=80",
  },
  {
    id: 2,
    name: "Robert Johnson",
    designation: "Product Manager",
    image:
      "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YXZhdGFyfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60",
  },
  {
    id: 3,
    name: "Jane Smith",
    designation: "Data Scientist",
    image:
      "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YXZhdGFyfGVufDB8fDB8fHww&auto=format&fit=crop&w=800&q=60",
  },
  {
    id: 4,
    name: "Emily Davis",
    designation: "UX Designer",
    image:
      "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fGF2YXRhcnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=800&q=60",
  },
  {
    id: 5,
    name: "Tyler Durden",
    designation: "Soap Developer",
    image:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=3540&q=80",
  },
  {
    id: 6,
    name: "Dora",
    designation: "The Explorer",
    image:
      "https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=3534&q=80",
  },
];

export default function Landing() {
  const navigate=useNavigate();
  const dispatch=useDispatch();

  const handleBecomeMentorClick=()=>{
    console.log('clicked become a mentor')
    navigate('/register');
    dispatch(setIsCreateMentor(true))

  }
  return (
    <div style={{marginTop:"18%"}}>
      <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight text-orange">
        Transform Your <br /> Passion into Expertise
      </h1>
      <p className="text-black mt-4 text-lg">
        &quot;Learn Anything, Teach Everything!&quot;
      </p>

      <div className="mt-8 flex items-center justify-center space-x-2">
        <div className="flex -space-x-2">
          <AnimatedTooltip items={people} />
        </div>
        <div className="text-black text-sm ">
          Trusted by <span className="text-orange font-semibold">27,000+</span>{" "}
          users
        </div>
      </div>

      <div className="mt-6">
        <button className="p-[3px] relative" onClick={()=>{handleBecomeMentorClick()}}>
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg" />
          <div className="px-8 py-2  bg-black rounded-[6px]  relative group transition duration-200 text-white hover:bg-transparent">
            Become a Mentor
          </div>
        </button>
      </div>
    </div>
  );
}
