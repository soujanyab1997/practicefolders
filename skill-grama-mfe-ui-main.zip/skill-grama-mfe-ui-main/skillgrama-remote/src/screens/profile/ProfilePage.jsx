import { useState } from "react";
import { IconCamera } from "@tabler/icons-react";
import { Input } from "../registerMentor/Input";
import "./ProfilePage.css";

const mockUser = {
  "userId": 1,
  "firstName": "John",
  "lastName": "Doe",
  "email": "john.doe@example.com",
  "bio": "Senior software Engineer",
  "experience": "5",
  "company": "TechCorp",
  "profilePic": "https://randomuser.me/api/portraits/men/3.jpg",
  "password": "password123",
  "ssoEnabled": true,
  "status": "Active",
  "isActive": false,
  "createdBy": 1,
  "createdDate": "2025-02-03T14:53:59",
  "lastModifiedBy": 3,
  "lastModifiedDate": "2025-02-03T14:53:59",
  "approvedBy": 2,
  "approvedOn": "2025-02-03T14:53:59"
};

function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false);
  const [updatedUser, setUpdatedUser] = useState(mockUser);

  const getInitials = (firstName, lastName) => `${firstName.charAt(0)}${lastName.charAt(0)}`;

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUpdatedUser((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setUpdatedUser((prevState) => ({
          ...prevState,
          photoURL: reader.result,
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const userProfile = updatedUser.profilePic ? (
    <img src={updatedUser.profilePic} alt="User Profile" className="profile-photo" />
  ) : (
    <div className="profile-initials">
      {getInitials(updatedUser.firstName, updatedUser.lastName)}
    </div>
  );

  const handleSave = () => {
    const payload = {
      ...updatedUser,
      firstName: updatedUser.firstName,
      lastName: updatedUser.lastName,
      phone: updatedUser.phone,
      role: updatedUser.role,
      experience: updatedUser.experience,
      company:updatedUser.company,
      status:updatedUser.status,
      bio:updatedUser.bio,
    };
    console.log("Payload: ", payload);
    // Call your save function or API here
  };

  return (
    <div className="profile-container">
      <div className="profile-header">
        <h1 className="text-3xl font-semibold text-orange">Profile</h1>
      </div>

      <div className="flex items-center space-x-4 mb-6">
        <div className="relative">
          {userProfile}
          <label htmlFor="photoUpload" className="camera-icon">
            <IconCamera size={24} color="white" />
          </label>
          <input id="photoUpload" type="file" onChange={handleImageChange} accept="image/*" className="hidden" />
        </div>
        <span className="text-lg font-semibold profile-text">{updatedUser.firstName} {updatedUser.lastName}</span>
      </div>

      <div className="personal-info">
        <h3 className="text-xl font-semibold profile-text">Personal Information</h3>
        <div className="space-y-3 mt-4">
          <div className="flex justify-between">
            <span className="label">Full Name:</span>
            {isEditing ? (
              <div className="flex space-x-2">
                <Input
                  name="firstName"
                  value={updatedUser.firstName}
                  onChange={handleChange}
                  className="name-input-field"
                />
                <Input
                  name="lastName"
                  value={updatedUser.lastName}
                  onChange={handleChange}
                  className="name-input-field"
                />
              </div>
            ) : (
              <span className="profile-text">{updatedUser.firstName} {updatedUser.lastName}</span>
            )}
          </div>

          <div className="flex justify-between">
            <span className="label">Email:</span>
            <span className="profile-text">{updatedUser.email}</span>
          </div>
          <div className="flex justify-between">
            <span className="label">Company:</span>
            {isEditing ? (
              <Input
                name="company"
                value={updatedUser.company}
                onChange={handleChange}
                className="input-field"
              />
            ) : (
              <span className="profile-text">{updatedUser.company}</span>
            )}
          </div>
          <div className="flex justify-between">
            <span className="label">Bio:</span>
            {isEditing ? (
              <Input
                name="bio"
                value={updatedUser.bio}
                onChange={handleChange}
                className="input-field"
              />
            ) : (
              <span className="profile-text">{updatedUser.bio}</span>
            )}
          </div>
          <div className="flex justify-between">
            <span className="label">Experience:</span>
            {isEditing ? (
              <Input
                name="experience"
                value={updatedUser.experience}
                onChange={handleChange}
                className="input-field"
              />
            ) : (
              <span className="profile-text">{updatedUser.experience} years</span>
            )}
          </div>
        </div>
      </div>

      <div className="mt-6 flex justify-end">
          <button
          className="bg-gradient-to-br relative group/btn from-black dark:from-zinc-900 dark:to-zinc-900 to-neutral-600 block dark:bg-zinc-800 w-full text-white rounded-md h-10 font-medium shadow-[0px_1px_0px_0px_#ffffff40_inset,0px_-1px_0px_0px_#ffffff40_inset] dark:shadow-[0px_1px_0px_0px_var(--zinc-800)_inset,0px_-1px_0px_0px_var(--zinc-800)_inset]"
          type="submit"
          onClick={() => {
            setIsEditing((prev) => !prev);
            if (isEditing) handleSave();
          }}
        >
          {isEditing ? "Save Changes" : "Edit Profile"}
        </button>
      </div>
    </div>
  );
}

export default ProfilePage;