import React,{ useState,useEffect } from "react";
import { useParams } from 'react-router-dom';
import { HoverEffect2 } from "../../components/ui/Cards2";
import { getSkillsbyCategory } from "../../Service/SkillService";

export default function ITSkillList() {
  const [skills,setSkills]=useState([]);
  const [field,setField]=useState('');
  const { id } = useParams();
 const fetchSkills=async()=>{
  try{
    let skillList=await getSkillsbyCategory(id);
    setField(skillList[0].fieldMaster.name)
      setSkills(skillList);
      console.log('skillList ',skillList)
  }
  catch(error)
  {
    console.log("Error",error);
  }
 }

 useEffect(()=>{
 if(id){
  fetchSkills(id)
 }},[id])

  return (
    <div className="max-w-5xl mx-auto px-8">
       <h1 className="text-4xl md:text-5xl font-bold text-black leading-tight">
        {field} Skill Stack
      </h1>
      
      <HoverEffect2  items={skills} />
      
    </div>
  );
}
export const projects = [
  {
    
    title: "Java",
    description:
      "A object-oriented programming language used for building platform-independent applications",
    link: "/skillpage",
  },
  {
    title: "ReactJS",
    description:
      "A JavaScript library for building dynamic user interfaces with reusable components.",
    link: "/skillpage",
  },
  {
    title: "NodeJS",
    description:
      "A runtime environment that allows executing JavaScript on the server side of web applications.",
    link: "/skillpage",
  },
  {
    title: "ServiceNow",
    description:
      "A cloud-based platform for managing IT service workflows and enterprise operations.",
    link: "/skillpage",
  },
  {
    title: "C++",
    description:
      "A general-purpose programming language with a focus on system-level programming.",
    link: "/skillpage",
  },
  {
    title: "Python",
    description:
      "A high level programming language known for its applicability in various domains.",
    link: "/skillpage",
  },
];
