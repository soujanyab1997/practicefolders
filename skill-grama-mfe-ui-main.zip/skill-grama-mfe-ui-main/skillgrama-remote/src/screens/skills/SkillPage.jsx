import React,{useState,useEffect} from "react";
import { Box, Typography,Card } from "@mui/material";
import { useParams } from 'react-router-dom';
import Image from "../../assets/JavaImage2.jpg";
import { AnimatedTestimonials } from "../../components/ui/Testimonial";
import { TypewriterEffectSmooth } from "../../components/ui/TypeWriterEffect";
import { getSkillbyID,getSkills } from "../../Service/SkillService";


const words = [
  {
    text: "What ",
    className: "text-white-300 dark:text-blue-300",
  },
  {
    text: "you ",
    className: "text-white-300 dark:text-blue-300",
  },
  {
    text: "can ",
    className: "text-white-300 dark:text-blue-300",
  },
  {
    text: "Expect:",
    className: "text-orange-500 dark:text-blue-500",
  },
];

const words2 = [
  {
    text: "Basics",
    className: "text-white-300 dark:text-blue-300",
  },
  {
    text: "To",
    className: "text-white-300 dark:text-blue-300",
  },
  {
    text: "Get",
    className: "text-white-300 dark:text-blue-300",
  },
  {
    text: "Started",
    className: "text-white-300 dark:text-blue-300",
  },
  {
    text: "with",
    className: "text-white-300 dark:text-blue-300",
  },
  {
    text: "Java:",
    className: "text-orange-500 dark:text-blue-500",
  },
];

const ExampleData = {
  
  title: "Java",
  description:
    "Java is a popular high-level, object-oriented programming language that was originally developed by Sun Microsystems and released in 1995. Currently, Java is owned by Oracle, and more than 3 billion devices run Java. Java runs on a variety of platforms, such as Windows, Mac OS, and the various versions of UNIX. Today Java is being used to develop numerous types of software applications, including desktop apps, mobile apps, web apps, games, and much more.",
};

const testimonials = [
  {
    quote:
      "A great session that boosted my confidence in Java with practical examples!",
    name: "Michael Rodriguez",
    designation: "Product Manager at TechFlow",
    contact: "michael@techflow.com",
    rating: 4,
    src: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=3560&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  },
  {
    quote:
      "Fantastic mentor—really clear explanations that made Java much more approachable!",
    name: "Sarah Chen",
    designation: "CTO at InnovateSphere",
    contact: "Sarah@Innovatesphere.com",
    rating: 4,
    src: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?q=80&w=3540&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  },
  {
    quote: "The mentor was knowledgeable, but the session felt a bit rushed.",
    name: "James Gunn",
    designation: "Operations Director at CloudScale",
    contact: "james@cloudscale.com",
    rating: 3,
    src: "https://images.unsplash.com/photo-1623582854588-d60de57fa33f?q=80&w=3540&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  },
  {
    quote:
      "I appreciated the personalized attention, but I wish we had covered more topics.",
    name: "James Kim",
    designation: "Engineering Lead at DataPro",
    contact: "Kim@datapro.com",
    rating: 2,
    src: "https://images.unsplash.com/photo-1636041293178-808a6762ab39?q=80&w=3464&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  },
  {
    quote:
      "Great mentor who took the time to clarify my doubts and offer valuable tips.",
    name: "Steven Smith",
    designation: "VP of Technology at FutureNet",
    contact: "steven@FutureNet.com",
    rating: 5,
    src: "https://images.unsplash.com/photo-1624561172888-ac93c696e10c?q=80&w=2592&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
  },
];

const SkillPage = () => {
   const [selectedskill,setSelectedSkill]=useState('');
   const { id } = useParams();
  console.log(id);

  const fetchSkillbyId=async(id)=>{
    try{
      const skill=await getSkillbyID(id); 
      setSelectedSkill(skill);
    }
    catch(error)
    {
        console.log("Error",error);
    }
  }

  useEffect(()=>{
    if(id){
    fetchSkillbyId(id)
  }},[id])
 
  return (
    <div style={{marginTop:"1%"}}>
    <Box sx={{ display: "flex",justifyContent:"space-around" }}>
      <Box sx={{width:"240%", backgroundColor:"white"}}>
        <img src={Image} alt="A Discussion" style={{paddingTop:'2%',width:"100%"}}/>
      </Box>
      <Card sx={{color:"white",backgroundColor:"white",width:"315%",boxShadow:"0"}}>
      <h1 className="text-2xl md:text-5xl lg:text-5xl font-bold text-center text-black relative z-2 font-sans" style={{paddingBottom:"3%"}}>
        About <span className="text-orange font-semibold">{selectedskill.name} </span>
      </h1>
      
        <Typography sx={{fontWeight:"700",pb:"2%",width:"75%",ml:"10%",color:"black"}}>{ExampleData.description}</Typography>
        
      </Card>
      
    </Box>
    <Box sx={{display:"flex",justifyContent:"space-around"}}>
    <Card sx={{color:"black", width:"50%", backgroundColor:"white",ml:"2%",boxShadow:"0",pt:"1%"}}>
    <TypewriterEffectSmooth words={words} />
    <ul className="max-w-md space-y-1 text-white-500 list-disc list-disclosure-close dark:text-gray-4000" style={{ paddingLeft: "6%",fontWeight:"750" ,paddingTop:"2%"}}>
        <li>
            Learn new concepts from the  industry experts
        </li>
        <li >
            Gain a foundational understanding of the subject
        </li>
        <li >
            Develop job-relevant skills with hands-on projects
        </li>
        <li >
            Create Real-Time Projects with mentor guidance.
        </li>
    </ul>
</Card>
<Card sx={{color:"black",width:"50%",backgroundColor:"white",pt:"1%",boxShadow:"0"}}>
<TypewriterEffectSmooth words={words2} />
<ul className="max-w-md space-y-1 text-wheat-500 list-disc list-disclosure-close  dark:text-gray-400" style={{ paddingLeft: "6%",fontWeight:"650" ,paddingTop:"2%"}}>
<li style={{textDecoration:"underline",color:"blue"}}>
    <a
      href="https://www.w3schools.com/java/java_getstarted.asp"
      target="_blank"
    >
    Getting Started with Java
    </a>
</li>
<li  style={{textDecoration:"underline",color:"blue"}}>
    <a
      href="https://www.tutorialspoint.com/java/java-features.htm"
      target="_blank"
      
    >
      Features in Java Language
    </a>
</li>
<li  style={{textDecoration:"underline",color:"blue"}}>
    <a
      href="https://www.geeksforgeeks.org/object-oriented-programming-oops-concept-in-java/"
      target="_blank"
      
    >
      Java OOPS Concepts
    </a>
</li>
<li  style={{textDecoration:"underline",color:"blue"}}>
    <a
      href="https://www.geeksforgeeks.org/collections-in-java-2/"
      target="_blank"
      
    >
      Collections in Java
    </a>
</li>
</ul>
</Card>

    </Box> 
    <div className="w-full bg-white flex flex-col items-center justify-center overflow-hidden rounded-md" style={{paddingTop:"5%"}}>
      <h1 className="md:text-5xl text-3xl lg:text-5xl font-bold text-center text-black relative z-20" style={{paddingBottom:"5%"}}>
        Meet Your Mentors
      </h1>
     
      <AnimatedTestimonials testimonials={testimonials} />
    </div>
  </div>
  );
};

export default SkillPage;
