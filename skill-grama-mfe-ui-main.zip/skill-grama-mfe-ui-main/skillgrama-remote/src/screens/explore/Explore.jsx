import SearchBar from "./SearchBar";
import React,{useEffect,useState} from 'react';
import { HoverEffect } from "../../components/ui/Cards";
import { FloatingNav } from "../../components/ui/FloatNav";
import { getallFields } from "../../Service/FieldService";

const navItems = [
  {
    name: "Home",
    link: "/",
  },
  {
    name: "explore",
    link: "/explore",
  },
  // {
  //   name: "Join",
  //   link: "/contact",
  //   icon: (
  //     <IconMessage className="h-4 w-4 text-neutral-500 dark:text-white" />
  //   ),
  // },
];


const projects = [
  {
    title: "Information Technology",
    description:
      "Information technology (IT) is a set of related fields that encompass computer systems, software, programming languages,and information processing.",
    link: "/itskills",
  },
  {
    title: "Programming Paradigm",
    description:
      "A streaming service that offers a variety of award-winning TV shows, movies and more on thousands of internet-connected devices.",
    link: "/itskills",
  },
  {
    title: "Cooking & Habitat",
    description:
      "A multinational technology company that specializes in Internet-related services and products.",
    link: "/itskills",
  },
  {
    title: "Marketing Strategy",
    description:
      "A technology company that focuses on building products that advance Facebook's mission of bringing the world closer together.",
    link: "/itskills",
  },
  {
    title: "Craft & Painting",
    description:
      "A multinational technology company focusing on e-commerce, cloud computing, digital streaming, and artificial intelligence.",
    link: "/itskills",
  },
  {
    title: "Resistors & Capacitors",
    description:
      "A multinational technology company that develops, manufactures, licenses, supports, and sells computer software, consumer electronics, personal computers, and related services.",
    link: "/itskills",
  },
];

export default function CardHoverEffectDemo() {

  const [categories,setCategories]=useState([]);
  
 const fetchCategories=async()=>{
  try{
      setCategories(await getallFields());
  }
  catch(error)
  {
    console.log("Error",error);
  }
 }

useEffect(()=>{
  fetchCategories()
},[categories])
 
  return (
    <div>
      <FloatingNav navItems={navItems}/>
    <div className="max-w-5xl mx-auto px-8">
      <SearchBar />
      <HoverEffect items={categories}/>
    </div>
    </div>
  );
}

