
import React, { useCallback } from "react";
import { useState, useMemo } from "react";
import {useNavigate} from "react-router-dom";
import _ from "lodash";
import personIcon from "@mui/icons-material/Person";
import BookIcon from "@mui/icons-material/Book";
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import { color } from "framer-motion";
import axios from "axios";
function debounce(func, delay){
  let timer;
  return function(...args){
    clearTimeout(timer);
    timer = setTimeout(() => 
    func.apply(this, args),delay);
  };
}

function SearchBar({onSelect}) {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);

  // const fetchSuggestions = useCallback(_.debounce((value) => {
  //   if(value.length > 1){
  //     const filteredResults  = mockData.filter((item) => item.name.toLowerCase().includes(value.toLowerCase()));
  //     setSuggestions(filteredResults);
  //   }
  //   else{
  //     setSuggestions([]);
  //   }
  // }, 300), [] );

  const fetchSuggestions = async (searchTerm) => {
    if(!searchTerm) {
      setSuggestions([]);
      return;
    }
    setLoading(true);
    try{
      const response = await axios.get(`http://localhost:8081/skill-grama-service/search/elasticSearch?query=${searchTerm}`);
      setSuggestions(response.data);
    }catch(error){
      console.log("Error fetching the suggestions: ",error);
      setSuggestions([]);
    }
    setLoading(false);
  }
  const debouncedfetch = debounce(fetchSuggestions, 300);

//   const debouncedSearch = useMemo(() => debounce((value) => {
//     if(!value.trim()){
//       setSuggestions([]);
//       return;
//     }
//     const filteredSuggestions = mockData.filter((item) =>
//       item.toLowerCase().includes(value.toLowerCase())
//   );
//   setSuggestions(filteredSuggestions);
//   },300),[]
// );
// const handleChange = (e) => {
//   const value = e.target.value;
//   setSearchTerm(value);
//   debouncedSearch(value);
// };
const handleChange = (e) => {
  const searchTerm = e.target.value;
  setQuery(searchTerm);
  debouncedfetch(searchTerm);
  
}
const handleSearch = (e) => {
  const value = e.target.value;
  setQuery(value);
  fetchSuggestions(value);
};

const handleSelect = (route) => {
  navigate(route);
  setQuery("");
  setSuggestions([]);
}

  return (
    <form className="flex items-center max-w-sm mx-auto" style={{paddingTop:"5%"}}>
      <div
      className="relative w-full">
       <div>
        <input
          type="text"
          value={query}
          onChange={handleChange}
          style={{borderStyle:'none', outline:'none'}}
          id="simple-search"
          className="gray-background border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          placeholder="Search a skill or topic"
          required
        />
        {loading && <p>Loading...</p>}
          <div 
        style={{
          width:"40px",
          height:"40px",
          padding : "10px",
          borderRadius : "0 5px 5px 0",
          
          // cursor : "pointer"
        }}
          // type="submit"
          className="absolute top-0 end-0 h-full p-2.5 text-sm font-medium text-white bg-white-700 rounded-e-lg border border-white-700 {/*hover:bg-blue-800*/} focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
        >
          <svg
            className="w-4 h-4"
            aria-hidden="true"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 20 20"
          >
            <path
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
            />
          </svg>
          <span className="sr-only">Search</span>
        </div>
        </div>
        <div>
        {suggestions.length > 0 && (
          <ul 
          style={{
            listStyleType: "none",
            padding: '0',
            borderRadius: "5px",
            backgroundColor: "white",
            maxHeight: '150px', // Fixed height to trigger scrolling
            overflowY: "auto",  // Enables vertical scrolling
            width: "100%",
            zIndex: "1000",
            position: 'absolute',
            marginBottom: "3px",
            boxShadow: "0px 4px 10px gray",
            scrollbarWidth: "thin", // For Firefox (optional)
            WebkitOverflowScrolling: "touch" // For smooth scrolling on iOS (optional)
          }}
          >
            {suggestions.sort((a, b) => a.length - b.length).map((item,index) => (
              <li
                key={index}
                style={{
                  padding : "10px",
                  cursor : "pointer",
                  maxHeight: '250px',
                  backgroundColor:"white",
                  color : "black",
                  //backgroundColor: index % 2 === 0 ? "#f9f9f9" : "#ffffff",
                  transition : "background-color 0.2 ease",
                  // borderBottom : index !== suggestions.length - 1 ? "1px solid #eee" : "none",
                }}
                 onMouseEnter={(e) => (e.target.style.backgroundColor = 'rgb(193, 193, 194)')}//rgb(73, 29, 141)'
                 onMouseLeave={(e) => (e.target.style.backgroundColor = "white" )}
                onClick={() => {
                  handleSelect(item.route)
                  // setSuggestions([]);
                  // onselect(item);
                }}
              >
                <span style={{flex:1}}> {item.name}</span>
                <span></span>
                {item.type === 'user' && <PersonOutlineIcon style = {{ marginLeft :"10px", color : "black"}}/>}
                {item.type === 'skill' && <BookIcon style = {{ marginLeft :"10px", color : "black"}}/>}
              </li>
            ))}
          </ul>
        )

        }
         </div>
      </div>
    </form>
  );
}

export default SearchBar;