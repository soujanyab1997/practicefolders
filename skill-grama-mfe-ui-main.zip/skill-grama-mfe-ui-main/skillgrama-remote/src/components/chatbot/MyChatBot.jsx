import React, { useState } from "react";
import ChatBot from "react-chatbotify";
import { useNavigate } from "react-router-dom";
const MyChatBot = () => {
  const navigate = useNavigate();
  const helpOptions = ["Home", "Explore", "Become a Mentor"];
  const flow = {
    start: {
      message: () => {
        const seenBefore = localStorage.getItem("Welcome");
        if (seenBefore) {
          return `Welcome back 😊!`;
        }
        return "Hi 😊!,Ready to explore something new Today? Let me help you find what you need";
      },
      function: (params) => localStorage.setItem("Welcome", params.userInput),
      path: "show_options",
    },
    show_options: {
      message:
        "We are here to help you, please select any option as per your need",
      options: helpOptions,
      path: "process_options",
    },
    prompt_again: {
      message: "Do you need any other help?",
      options: helpOptions,
      path: "process_options",
    },
    unknown_input: {
      message:
        "Sorry, I do not understand your message 😢! If you require further assistance, you may click on " +
        "the Github option and open an issue there or visit our discord.",
      options: helpOptions,
      path: "process_options",
    },
    process_options: {
      transition: { duration: 0 },
      chatDisabled: true,
      path: async (params) => {
        let link = "";
        switch (params.userInput) {
          case "Home":
            link = "/";
            break;
          // case "Login":
          //   link = "/explore";
          //   break;
          // case "SignUp":
          //   link = "/explore";
          //   break;
          case "Explore":
            link = "/explore";
            break;
          case "Become a Mentor":
            link = "/register";
            break;
          default:
            return "unknown_input";
        }
        await params.injectMessage("Sit tight! I'll send you right there!");
        setTimeout(() => {
          // window.location.href = link;
          navigate(link)
        }, 1000);
        return "repeat";
      },
    },
    repeat: {
      transition: { duration: 3000 },
      path: "prompt_again",
    },
  };

  const settings = {
    isOpen: false,
    general: {
      primaryColor: "#42b0c5",
      secondaryColor: "#491d8d",
      fontFamily: "Arial, sans-serif",
      embedded: false,
    },
    audio: {
      disabled: false,
    },
    chatHistory: {
      storageKey: "concepts_settings",
    },
    // chatWindow:{
    //   defaultOpen:true,
    // },
    tooltip: {
      mode: "CLOSE",
      text: "May i help you!",
    },
    header: {
      title: <div>SkillGrama ChatBot</div>,
    },

    footer: {
      text: (
        <div
          style={{
            cursor: "pointer",
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            columnGap: 3,
          }}
        >
          <span key={2} style={{ fontWeight: "bold" }}>
            Powered by SkillGrama
          </span>
        </div>
      ),
    },
  };

  return (
    <div>
      <ChatBot settings={settings} flow={flow} />
    </div>
  );
};
export default MyChatBot;
