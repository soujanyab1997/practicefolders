const mockData = [
  {
    "id": 4,
    "name": "Java",
    "description": "A programming language for web development",
    "type": "skill",
    "route": "/skill/4"
  },
  {
    "id": 1,
    "name": "JavaScript",
    "description": "A programming language for web development",
    "type": "skill",
    "route": "/skill/1"
  },
  {
    "id": 1,
    "name": "John Doe",
    "description": "Bio of John Doe",
    "type": "user",
    "route": "/profile/1"
  },
  {
    "id": 3,
    "name": "Field C",
    "description": "Description for Field C",
    "type": "field",
    "route": "/explore/3"
  },
  {
    "id": 2,
    "name": "Field B",
    "description": "Description for Field B",
    "type": "field",
    "route": "/explore/2"
  },
  {
    "id": 1,
    "name": "Field A",
    "description": "Description for Field A",
    "type": "field",
    "route": "/explore/1"
  }
]

export default mockData;