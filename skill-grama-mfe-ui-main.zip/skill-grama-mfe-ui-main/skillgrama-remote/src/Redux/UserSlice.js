import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  isCreateMentor: false
};

const userSlice = createSlice({
  name: "users",
  initialState,
  reducers: {
    setIsCreateMentor: (state, action) => {
      state.isCreateMentor=action.payload;
    }
  },
});

export const { addUser, setIsCreateMentor} = userSlice.actions;

export default userSlice.reducer;