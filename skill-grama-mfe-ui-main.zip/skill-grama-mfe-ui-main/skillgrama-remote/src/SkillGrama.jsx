import { Provider } from "react-redux"
import { store } from "./Redux/Store"
import { BrowserRouter } from "react-router-dom"
import App from "./App"

const SkillGrama = () => {
    return (
        <Provider store={store}>
            <BrowserRouter basename="/skillgrama">
                <App />
            </BrowserRouter>
        </Provider>
    )
}

export default SkillGrama;