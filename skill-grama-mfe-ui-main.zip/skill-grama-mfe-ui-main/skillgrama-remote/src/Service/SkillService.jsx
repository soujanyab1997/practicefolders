
import axios from 'axios';
const API_URL = 'http://localhost:8081/skill-grama-service/api/skills';

//Get All skills
export const getSkills=async()=>{

    try{
        const response=await axios.get(`${API_URL}`);
      
        return response.data;
    }
    catch(error)
    {
        console.log("Error",error);
    }
}

//Get Skill by ID
export const getSkillbyID=async(id)=>{

    try{
        const response=await axios.get(`${API_URL}/${id}`);
        
        return response.data;
    }
    catch(error)
    {
        console.log("Error",error);
    }
}


//Get Skill by name
export const getSkillbyName=async(name)=>{

    try{
        const response=await axios.get(`${API_URL}/name/${name}`);
        return response.data;
    }
    catch(error)
    {
        console.log("Error",error);
    }
}

//Get Skill by description
export const getSkillbyDescription=async(description)=>{

    try{
        const response=await axios.get(`${API_URL}/description/${description}`);
        return response.data;
    }
    catch(error)
    {
        console.log("Error",error);
    }
}

//Get Skills by Category(Field_Id)
export const getSkillsbyCategory=async(fieldId)=>{

    try{
        const response=await axios.get(`${API_URL}/field/${fieldId}`);
        return response.data;
    }
    catch(error)
    {
        console.log("Error",error);
    }
}