import axios from 'axios';
const API_URL = 'http://localhost:8081/skill-grama-service/user/';


export const fetchUserData = async(userId) => {
    try{
        const response = await axios.get(`${API_URL}/${userId}`);
        return response.data;
    }
    catch(error){
        console.error("Error fetching user data: ", error);
        return null;
    }
};

export const updateUserProfile = async(userId, updatedData) => {
    try{
        const response = await axios.put(`${API_URL}/${userId}`, updatedData, {
            headers : {
                "Content-Type":"application/json",
            },
        });
        return response.data;
    }
    catch(error){
        console.error("Error updating the user profile: ",error);
        return null;
    }
}