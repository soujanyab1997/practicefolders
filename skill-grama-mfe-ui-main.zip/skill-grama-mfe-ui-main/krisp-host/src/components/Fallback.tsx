import { Card, CardBody, Typography } from "@material-tailwind/react";

const Fallback = () => {
    return (
        <div className='p-10 bg-[#ffffefb8] flex justify-center items-center w-screen h-screen'>
            <Card className="mt-6 w-90 shadow-xl hover:bg-neutral-200 w-100">
                <CardBody className='p-10 px-8'>
                    <Typography variant="h4" color="blue-gray" className="rounded">
                        Oops! Something went wrong!
                    </Typography>
                </CardBody>
                <Typography variant="h6" color="blue-gray" className="rounded hover:cursor-pointer hover:underline text-center" onClick={() => {
                    window.location.href = '/';
                }}>
                    Click here to refresh to home
                </Typography>
            </Card>
        </div>
    )

}
export default Fallback;