import React, { Suspense } from 'react';
import './App.css'
import LandingPage from './Pages/LandingPage/LandingPage'
// import SkillGrama from 'skillGrama/SkillGrama';
import { BrowserRouter, Route, Routes } from 'react-router';
import { ErrorBoundary } from 'react-error-boundary';
import Fallback from './components/Fallback';
const SkillGrama = React.lazy(() => import('skillGrama/SkillGrama'));

function App() {

  return (
    <>
      <BrowserRouter>
        <ErrorBoundary fallback={<Fallback />}>
          <Routes>
            <Route index element={<LandingPage />} />
            <Route path='/skillgrama/*' element={
              <Suspense fallback={<div>Loading...</div>}>
                <SkillGrama />
              </Suspense>} />
          </Routes>
        </ErrorBoundary>
      </BrowserRouter>
    </>
  )
}

export default App
