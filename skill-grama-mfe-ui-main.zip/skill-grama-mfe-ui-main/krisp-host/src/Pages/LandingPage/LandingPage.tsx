import React from 'react';
import {
    Card,
    CardHeader,
    CardBody,
    CardFooter,
    Typography,
    Button,
} from "@material-tailwind/react";
import { Link } from 'react-router';

const LandingPage = () => {
    return (
        <div className='p-[2%] bg-[#ffffefb8]'>
            <Typography variant="h1" className='text-left text-[#ff0500]'>KRiSP</Typography>
            <Typography variant="h1" color='gray' className='text-left'>Hello Colleagues!</Typography>
            <Typography variant="h3" color='gray' className='text-left'>Please choose an option to proceed</Typography>
            <section className='py-10 px-8'>
                <div className="mx-auto text-center mb-16">
                    <div className="mx-auto container">
                        <div className="grid grid-cols-4 gap-8">
                            <Link to={'/expense'}>
                                <Card className="mt-6 w-90 shadow-xl hover:bg-neutral-200">
                                    <CardBody className='p-10 px-8'>
                                        <img src='./intelliflow.svg' className="h-60 w-84 object-contain" alt='INTELLIFLOW' />
                                    </CardBody>
                                    <Typography variant="h3" color="blue-gray" className="bg-[#d5e0f2] align-top inset-shadow-sm rounded">
                                        IntelliFlow
                                    </Typography>
                                </Card>
                            </Link>
                            <Link to="#" underline='none'>
                                <Card className="mt-6 w-90 shadow-xl hover:bg-neutral-200">
                                    <CardBody className='p-10 px-8'>
                                        <img src='./insight360.svg' className="h-60 w-84 object-contain" alt='INSIGHT360' />
                                    </CardBody>
                                    <Typography variant="h3" color="blue-gray" className="bg-[#d5e0f2] align-top inset-shadow-sm rounded">
                                        Insight360
                                    </Typography>
                                </Card>
                            </Link>
                            <Link to="#" underline='none'>
                                <Card className="mt-6 w-90 shadow-xl hover:bg-neutral-200">
                                    <CardBody className='p-10 px-8'>
                                        <img src='./pathfinder.svg' className="h-60 w-84 object-contain" alt='PATHFINDER' />
                                    </CardBody>
                                    <Typography variant="h3" color="blue-gray" className="bg-[#d5e0f2] align-top inset-shadow-sm rounded">
                                        PathFinder
                                    </Typography>
                                </Card>
                            </Link>
                            <Link to="/skillgrama" underline='none'>
                                <Card className="mt-6 w-90 shadow-xl hover:bg-neutral-200">
                                    <CardBody className='p-10 px-8'>
                                        <img src='./skillgrama.svg' className="h-60 w-84 object-contain" alt='SKILLGRAMA' />
                                    </CardBody>
                                    <Typography variant="h3" color="blue-gray" className="bg-[#d5e0f2] align-top inset-shadow-sm rounded">
                                        SkillGrama
                                    </Typography>
                                </Card>
                            </Link>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
};

export default LandingPage;