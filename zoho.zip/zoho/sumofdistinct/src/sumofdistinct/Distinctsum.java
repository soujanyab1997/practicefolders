package sumofdistinct;

public class Distinctsum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[]= {};
int sum=0;
int n=arr.length;
for(int i=0;i<n;i++) 
{
	for(int j=i+1;j<n;j++)
		{
		if(arr[i]==arr[j]) 
		{

			//System.out.println(arr[j]+"j");
			arr[j]=j+1;

			System.out.println(arr[j]+"arr[j]"+j+"j");
			int count=j;
			System.out.println(count+"count");
			while(count!=0) {
				for(int p=j-1;p>=0;p--) {
				int temp=arr[j];
				if(arr[p]==temp) {
					System.out.println(arr[j]+"after loop");
					arr[j]=arr[j]+1;
				}
			}
				count--;
			}
		}
		}
}
for(int i=0;i<arr.length;i++) {
			sum=sum+arr[i];
			System.out.println(arr[i]);
}
System.out.println(sum);
	}

}

//5,7,4,3,3,1=>5,7,4,3,6,1
//1,2,5,1,2=>1,2,5,4,6
//8,7,6,5,5=>8,7,6,5,9
//5,6,7,8,5=>5,6,7,8,9
