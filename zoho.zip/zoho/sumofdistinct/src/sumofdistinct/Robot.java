package sumofdistinct;

public class Robot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int initial[]= {3,2};
String str="R3R2L3U4D3D3U2";
String ch[]=str.split("\n");
char c[]=new char[str.length()];
for(int i=0;i<str.length();i++) {
	c[i]=str.charAt(i);
}
//for(int i=0;i<str.length();i++) {
//	System.out.println(c[i]);
//}

//System.out.println(initial[0]);
System.out.println(c[1]);
for(int i=0;i<str.length();i++) {
	if(c[i]=='R') {
		initial[0]=initial[0]+c[i+1];
		System.out.println();
	}
	else if(c[i]=='L') {
		initial[0]=initial[0]-c[i+1];
	}
	else if(c[i]=='U') {
		initial[1]=initial[1]+c[i+1];
		
	}else {
		initial[1]=initial[1]-c[i-1];
	}
}
	System.out.println("final point"+initial[0]);

	System.out.println("final point"+initial[1]);
}
}

